
public class Work17 {

	public static void main(String[] args) {

		totalPeach();
	}

	public static void totalPeach() {
		int t = 1;
		for (int i = 1; i < 10; i++) {
			t = (t + 1) * 2;
		}
		System.out.println("桃子总个数为" + t);

	}

}
/*桃子总个数为1534*/
